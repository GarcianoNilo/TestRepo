<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// Add a simple command to fix the current version issue
Artisan::command('fix:current-version {tenant} {version?}', function ($tenant, $version = null) {
    $this->info("Setting current version for tenant: {$tenant}");
    
    if (!$version) {
        $version = 'v1.1.4'; // Default to the version in your path
        $this->info("No version specified, using: {$version}");
    }
    
    try {
        // Initialize tenant
        tenancy()->initialize($tenant);
        
        // Check if the version exists
        $exists = DB::table('system_versions')
            ->where('version', $version)
            ->exists();
        
        if (!$exists) {
            $this->error("Version {$version} doesn't exist in the database!");
            $versions = DB::table('system_versions')->pluck('version')->toArray();
            
            if (empty($versions)) {
                $this->error("No versions found in database. Make sure you've checked for updates first.");
                return 1;
            }
            
            $this->info("Available versions: " . implode(', ', $versions));
            return 1;
        }
        
        // Clear any existing current versions
        DB::table('system_versions')
            ->where('is_current', true)
            ->update([
                'is_current' => false,
                'updated_at' => now()
            ]);
        
        // Set the specified version as current
        DB::table('system_versions')
            ->where('version', $version)
            ->update([
                'is_current' => true,
                'is_active' => true,
                'installed_at' => now(),
                'updated_at' => now()
            ]);
        
        $this->info("Success! Version {$version} is now set as the current version.");
        $this->info("Refresh your system versions page to see all the updates and rollbacks.");
        
    } catch (\Exception $e) {
        $this->error("Error: " . $e->getMessage());
        return 1;
    } finally {
        // End tenancy
        tenancy()->end();
    }
    
    return 0;
})->purpose('Fix the current version for a tenant so that GitHub releases display correctly');
