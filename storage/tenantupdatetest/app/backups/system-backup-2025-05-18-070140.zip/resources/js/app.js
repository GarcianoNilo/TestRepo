import './bootstrap';
import './components/confirm-dialog';
import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
